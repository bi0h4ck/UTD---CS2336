import Customer.*;


import java.io.IOException;


/**
 * Created by diempham on 2/18/17.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        ProcessOrder processOrder = new ProcessOrder();
        processOrder.run();
    }
}

